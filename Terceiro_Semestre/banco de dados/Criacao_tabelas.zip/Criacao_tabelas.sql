
USE CRM_BD;
GO

-- Cria o esquema CRM no banco de dados CRM_BD
CREATE SCHEMA CRM;
GO

-- Cria a tabela Pessoa no esquema CRM
CREATE TABLE CRM.Pessoa (id_pessoa int IDENTITY(1,1) PRIMARY KEY, 
tipo_pessoa varchar(2) not null,
nome_pessoa varchar(50) not null,
data_nascimento date not null,
nome_pai varchar(50) null,
nome_mae varchar(50) null,
renda_mensal decimal(18, 2),
observacao varchar(300)
);
GO

-- Cria a tabela Pessoa_Documento no esquema CRM
CREATE TABLE CRM.Pessoa_Documento (
id_pessoa_documento int IDENTITY(1,1) not null, 
id_pessoa int not null,
tipo_documento varchar(20) not null,
numero_documento varchar(50) not null,
data_expedicao date not null,
data_validade date null,
CONSTRAINT PK_Pessoa_Documento PRIMARY KEY (id_pessoa_documento),
CONSTRAINT FK_Pessoa_Documento FOREIGN KEY (id_pessoa)
REFERENCES CRM.Pessoa(id_pessoa)
);
GO

-- Adiciona chave estrangeira na tabela
ALTER TABLE CRM.Pessoa_Documento 
ADD CONSTRAINT FK_Pessoa_Documento FOREIGN KEY (id_pessoa)
REFERENCES CRM.Pessoa(id_pessoa);

-- Inser��o de dados nas tabelas
INSERT INTO CRM.Pessoa (tipo_pessoa, nome_pessoa, data_nascimento, nome_pai, nome_mae, renda_mensal, observacao)
VALUES ('PF', 'Peter Chen', '1947/01/03', '', '', '10000.00', '')

INSERT INTO CRM.Pessoa_Documento (id_pessoa, tipo_documento, numero_documento, data_expedicao, data_validade)
VALUES (1, 'CPF', '022094775-40', '2003/05/23', '');

SELECT * FROM CRM.Pessoa;
SELECT * FROM CRM.Pessoa_Documento;

-- Insere novos documentos para id_pessoa=1
INSERT INTO CRM.Pessoa_Documento (id_pessoa, tipo_documento, numero_documento, data_expedicao, data_validade)
VALUES (1, 'RG', '08889812-8', '1990/04/01', '');
INSERT INTO CRM.Pessoa_Documento (id_pessoa, tipo_documento, numero_documento, data_expedicao, data_validade)
VALUES (1, 'PASSAPORTE', 'CY9746510182', '2019/08/05', '');

-- Recupera dados das duas tabelas com operador JOIN
SELECT p.nome_pessoa, p.data_nascimento, pd.tipo_documento, pd.numero_documento
FROM CRM.Pessoa p
JOIN CRM.Pessoa_Documento pd ON (pd.id_pessoa = p.id_pessoa)
WHERE data_nascimento BETWEEN '1947/01/01' AND '1947/12/31'
ORDER BY nome_pessoa;

-- Atividade pr�tica
-- Cria��o da tabela CRM.Pessoa_Endereco
CREATE TABLE CRM.Pessoa_Endereco (
id_pessoa_endereco int IDENTITY(1,1) not null, 
id_pessoa int not null,
tipo_endereco varchar(20) not null,
tipo_logradouro varchar(20) not null,
logradouro varchar(50) not null,
numero int not null,
complemento varchar(50) null,
bairro varchar(50) not null,
cidade varchar(50) not null,
estado varchar(2) not null,
cep varchar(10) not null,
CONSTRAINT PK_Pessoa_Endereco PRIMARY KEY (id_pessoa_endereco),
CONSTRAINT FK_Pessoa_Endereco FOREIGN KEY (id_pessoa) REFERENCES CRM.Pessoa(id_pessoa),
CONSTRAINT CHK_Tipo_Endereco CHECK (tipo_endereco IN ('Residencial', 'Comercial', 'Outro'))
);
GO

-- Cria��o de tabela com VARBINARY(MAX)
CREATE TABLE CRM.Pessoa_Imagem (id_pessoa_imagem int PRIMARY KEY, 
id_documento int null, imagem VARBINARY(MAX) not null,
CONSTRAINT FK_Pessoa_Imagem_Documento FOREIGN KEY (id_documento) 
REFERENCES CRM.Pessoa_Documento(id_pessoa_documento)
)
GO

-- Inser��o de dados nas tabelas
INSERT INTO CRM.Pessoa_Imagem (id_pessoa_imagem, id_documento, imagem) 
VALUES (1, 1,
(SELECT * FROM OPENROWSET(BULK 'C:\Temp\cpf.png', SINGLE_BLOB) AS imagem));
GO

SELECT p.nome_pessoa, p.data_nascimento, pd.tipo_documento, pd.numero_documento, pi.imagem
FROM CRM.Pessoa p
JOIN CRM.Pessoa_Documento pd ON (pd.id_pessoa = p.id_pessoa)
JOIN CRM.Pessoa_Imagem pi ON (pi.id_documento = pd.id_pessoa_documento)
WHERE data_nascimento BETWEEN '1947/01/01' AND '1947/12/31'
ORDER BY nome_pessoa;

-- Recupera��o da imagem e exporta��o para arquivo
DECLARE @sql VARCHAR(1000);
SET @sql = 'BCP "SELECT imagem FROM CRM.Pessoa_Imagem WHERE id_pessoa_imagem=1 " 
QUERYOUT C:\Temp\cpf_1.png -T -f "C:\Temp\cpf_1.fmt" -S ' + @@SERVERNAME;
EXEC master.dbo.xp_cmdshell @sql;

-- Cria��o de tabela com FILESTREAM
CREATE TABLE CRM.Pessoa_Imagem (id_pessoa int PRIMARY KEY, 
id_documento null,
[UI] UNIQUEIDENTIFIER ROWGUIDCOL not null UNIQUE DEFAULT (newid()),
imagem VARBINARY(MAX) FILESTREAM not null,
CONSTRAINT FK_Pessoa_Imagem_Documento FOREIGN KEY (id_documento) 
REFERENCES CRM.Documento(id_documento)
)
GO

-- Cria��o de banco de dados habilitado para FILESTREAM
USE master;
GO

CREATE DATABASE IBMEC
ON PRIMARY  ( NAME='CRM_Primary',
    FILENAME='C:\MSSQL\data\CRM.mdf',
    SIZE=4MB, MAXSIZE=10MB, FILEGROWTH=1MB),
FILEGROUP CRM_FG1 ( NAME = 'CRM_FG1_Dat1',
    FILENAME = 'C:\MSSQL\data\CRM_FG1_1.ndf',
    SIZE = 1MB, MAXSIZE=10MB, FILEGROWTH=1MB),
  ( NAME = 'CRM_FG1_Dat2',
    FILENAME = 'C:\MSSQL\data\CRM_FG1_2.ndf',
    SIZE = 1MB, MAXSIZE=10MB, FILEGROWTH=1MB),
FILEGROUP FileStreamGroup1 CONTAINS FILESTREAM
  ( NAME = 'CRM_FG_FS', FILENAME = 'C:\MSSQLFilestream')
LOG ON
  ( NAME='CRM_log',
    FILENAME = 'C:\MSSQL\data\CRM.ldf',
    SIZE=1MB, MAXSIZE=10MB, FILEGROWTH=1MB);
GO
ALTER DATABASE CRM MODIFY FILEGROUP CRM_FG1 DEFAULT;
GO

-- Para recome�ar
DROP TABLE CRM.Pessoa_Imagem;
DROP TABLE CRM.Pessoa_Endereco;
DROP TABLE CRM.Pessoa_Documento;
DROP TABLE CRM.Pessoa;

