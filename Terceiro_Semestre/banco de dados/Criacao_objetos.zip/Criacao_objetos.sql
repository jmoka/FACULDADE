USE CRM_BD;
GO

-- Cria��o de view
CREATE VIEW CRM.vw_pessoa_documento AS
SELECT p.nome_pessoa, p.data_nascimento, pd.tipo_documento, pd.numero_documento
FROM CRM.Pessoa p
JOIN CRM.Pessoa_Documento pd ON (pd.id_pessoa = p.id_pessoa)
GO

-- Select na view
SELECT * FROM CRM.vw_pessoa_documento
WHERE data_nascimento BETWEEN '1947/01/01' AND '1947/12/31'
ORDER BY nome_pessoa;
GO

-- Atividade pr�tica
-- Cria��o da view CRM.vw_pessoa_documento_endereco
CREATE VIEW CRM.vw_pessoa_documento_endereco AS
SELECT p.*, pd.tipo_documento, pd.numero_documento, 
pe.tipo_logradouro, pe.logradouro, pe.numero, pe.complemento, 
pe.bairro, pe.cidade, pe.estado, pe.cep
FROM CRM.Pessoa p
JOIN CRM.Pessoa_Documento pd ON (pd.id_pessoa = p.id_pessoa)
JOIN CRM.Pessoa_Endereco pe ON (pe.id_pessoa = p.id_pessoa)
WHERE pe.tipo_endereco='Residencial'
GO

-- Cria��o de Stored Procedure
CREATE PROCEDURE CRM.proc_insere_pessoa
@tipo_pessoa varchar(2),
@nome_pessoa varchar(50),
@data_nascimento date,
@nome_pai varchar(50),
@nome_mae varchar(50),
@renda_mensal decimal(18, 2),
@observacao varchar(300)
AS
BEGIN
	IF @tipo_pessoa IS NULL
		RAISERROR('Par�metro tipo_pessoa � obrigat�rio.', 16, 1);
	IF @nome_pessoa IS NULL
		RAISERROR('Par�metro nome_pessoa � obrigat�rio.', 16, 1);
	IF @data_nascimento IS NULL
		RAISERROR('Par�metro data_nascimento � obrigat�rio.', 16, 1);

	IF NOT EXISTS (SELECT 1 FROM CRM.Pessoa WHERE nome_pessoa=@nome_pessoa AND data_nascimento=@data_nascimento)
	BEGIN
		INSERT INTO CRM.Pessoa (tipo_pessoa, nome_pessoa, data_nascimento, nome_pai, nome_mae, renda_mensal, observacao)
		VALUES (@tipo_pessoa, @nome_pessoa, @data_nascimento, @nome_pai, @nome_mae, @renda_mensal, @observacao)
	END
	ELSE
	BEGIN
		RAISERROR('Pessoa j� cadastrada.', 16, 1);
	END
END
GO

EXEC CRM.proc_insere_pessoa 'PF', 'Ada Lovelace', '1815/12/10', '', '', '10100.00', '';
SELECT * FROM CRM.Pessoa;
GO

-- Cria��o de Stored Procedure
CREATE PROCEDURE CRM.proc_deleta_pessoa
@id_pessoa int
AS
BEGIN
	IF @id_pessoa IS NULL
		RAISERROR('Par�metro id_pessoa � obrigat�rio.', 16, 1);

	IF EXISTS (SELECT 1 FROM CRM.Pessoa WHERE id_pessoa=@id_pessoa)
	BEGIN
		DELETE FROM CRM.Pessoa WHERE id_pessoa=@id_pessoa;
	END
	ELSE
	BEGIN
		RAISERROR('Pessoa n�o cadastrada.', 16, 1);
	END
END
GO

EXEC CRM.proc_deleta_pessoa 2;
SELECT * FROM CRM.Pessoa;

-- Cria��o de Stored Procedure
CREATE PROCEDURE CRM.proc_atualiza_pessoa
@id_pessoa int,
@tipo_pessoa varchar(2),
@nome_pessoa varchar(50),
@data_nascimento date,
@nome_pai varchar(50),
@nome_mae varchar(50),
@renda_mensal decimal(18, 2),
@observacao varchar(300)
AS
BEGIN
	IF @tipo_pessoa IS NULL
		RAISERROR('Par�metro tipo_pessoa � obrigat�rio.', 16, 1);
	IF @nome_pessoa IS NULL
		RAISERROR('Par�metro nome_pessoa � obrigat�rio.', 16, 1);
	IF @data_nascimento IS NULL
		RAISERROR('Par�metro data_nascimento � obrigat�rio.', 16, 1);

	IF EXISTS (SELECT 1 FROM CRM.Pessoa WHERE id_pessoa=@id_pessoa)
	BEGIN
		UPDATE CRM.Pessoa SET tipo_pessoa=@tipo_pessoa, nome_pessoa=@nome_pessoa, 
		data_nascimento=@data_nascimento, nome_pai=@nome_pai, nome_mae=@nome_mae, 
		renda_mensal=@renda_mensal, observacao=@observacao
		WHERE id_pessoa=@id_pessoa;
	END
	ELSE
	BEGIN
		RAISERROR('Pessoa n�o cadastrada.', 16, 1);
	END
END
GO

EXEC CRM.proc_atualiza_pessoa 2, 'PF', 'Ada Lovelace', '1815/12/10', '', '', '10900.00', '';
SELECT * FROM CRM.Pessoa;

-- Cria��o de trigger
ALTER TABLE CRM.Pessoa ADD data_ultima_atualizacao datetime;
GO

CREATE TRIGGER CRM.trg_Pessoa_data_atualizacao ON CRM.Pessoa
AFTER UPDATE
AS 
BEGIN
    UPDATE CRM.Pessoa 
    SET data_ultima_atualizacao = GETDATE()
	FROM Inserted
	WHERE CRM.Pessoa.id_pessoa=Inserted.id_pessoa
END
GO

EXEC CRM.proc_atualiza_pessoa 2, 'PF', 'Ada Lovelace', '1815/12/10', '', '', '11100.00', '';
SELECT * FROM CRM.Pessoa;

-- Cria��o da tabela CRM.Pessoa_archive
CREATE TABLE CRM.Pessoa_archive (id_pessoa int IDENTITY(1,1) PRIMARY KEY, 
tipo_pessoa varchar(2) not null,
nome_pessoa varchar(50) not null,
data_nascimento date not null,
nome_pai varchar(50) null,
nome_mae varchar(50) null,
renda_mensal decimal(18, 2),
observacao varchar(300),
data_ultima_atualizacao datetime
);
GO

-- Cria trigger para dele��o
CREATE TRIGGER CRM.trg_Pessoa_deleta ON CRM.Pessoa
AFTER DELETE
AS 
BEGIN
	INSERT INTO CRM.Pessoa_archive (tipo_pessoa, nome_pessoa, data_nascimento, 
	nome_pai, nome_mae, renda_mensal, observacao, data_ultima_atualizacao)
	SELECT tipo_pessoa, nome_pessoa, data_nascimento, nome_pai, nome_mae, 
	renda_mensal, observacao, data_ultima_atualizacao
	FROM Deleted
END

EXEC CRM.proc_deleta_pessoa 2
SELECT * FROM CRM.Pessoa;
SELECT * FROM CRM.Pessoa_archive;

-- Cria��o de fun��o
CREATE FUNCTION CRM.fn_idade (@data_nascimento date)
RETURNS int
AS
BEGIN
	DECLARE @idade int
	SELECT @idade = DATEDIFF(year, @data_nascimento, GETDATE());
	RETURN @idade
END
GO

SELECT nome_pessoa, data_nascimento, CRM.fn_idade(data_nascimento) AS idade
FROM CRM.Pessoa;

-- Cria��o de fun��o
CREATE FUNCTION CRM.fn_maiores (@idade int)
RETURNS TABLE
AS
RETURN
	SELECT * FROM CRM.Pessoa WHERE CRM.fn_idade(data_nascimento) > @idade;
GO

-- Select na fun��o
SELECT * FROM CRM.fn_maiores(18);

-- Para testar NEWID()
SELECT ABS(CHECKSUM(NEWID()) % 10)
SELECT ABS(CHECKSUM(NEWID())) / 100000
SELECT DATEADD(day, (ABS(CHECKSUM(NEWID())) / 100000 * -1), CONVERT(DATE, GETDATE()))

-- Insere dados na tabela CRM.Pessoa
DECLARE @i AS int = 2
DECLARE @nome_pessoa AS varchar(255)
DECLARE @data_nascimento AS date
DECLARE @renda_mensal AS decimal(18, 2)
WHILE @i < 100000
BEGIN
    SET @i = @i + 1
	SELECT @nome_pessoa = CONVERT(varchar(50), NEWID())
	SELECT @data_nascimento = DATEADD(day, (ABS(CHECKSUM(NEWID())) / 100000 * -1), CONVERT(DATE, GETDATE()))
	SELECT @renda_mensal = ABS(CHECKSUM(NEWID())) / 100000
	EXEC CRM.proc_insere_pessoa 'PF', @nome_pessoa, @data_nascimento, '', '', @renda_mensal, '';
END

-- SELECT ap�s a carga
SELECT COUNT(*) AS [Quantidade de linhas] FROM CRM.Pessoa;
SELECT TOP(10) nome_pessoa, data_nascimento, renda_mensal FROM CRM.Pessoa;

-- SELECT com WHERE na data_nascimento
-- Para mostrar o plano de execu��o de uma consulta, selecinar a consulta e usar CTRL-L
SELECT nome_pessoa, data_nascimento, CRM.fn_idade(data_nascimento) AS idade
FROM CRM.Pessoa 
WHERE data_nascimento >= '2020/01/01'

-- Cria��o do �ndice
CREATE NONCLUSTERED INDEX ind_Pessoa_data_nascimento ON CRM.Pessoa (data_nascimento);

-- Verificar plano de execu��o da consulta ap�s cria��o do �ndice
SELECT nome_pessoa, data_nascimento, CRM.fn_idade(data_nascimento) AS idade
FROM CRM.Pessoa 
WHERE data_nascimento >= '2020/01/01'

SELECT nome_pessoa, data_nascimento, CRM.fn_idade(data_nascimento) AS idade
FROM CRM.Pessoa 
WHERE data_nascimento >= '2021/05/01'

-- Para recome�ar
DROP VIEW CRM.vw_pessoa_documento;
DROP PROCEDURE CRM.proc_insere_pessoa;
DROP PROCEDURE CRM.proc_deleta_pessoa;
DROP PROCEDURE CRM.proc_atualiza_pessoa;
DROP TRIGGER CRM.trg_data_atualizacao
DROP TRIGGER CRM.trg_data_deleta
DROP FUNCTION CRM.fn_idade
DROP FUNCTION CRM.fn_maiores
