USE CRM_BD;
GO

-- Verificar plano de execu��o da consulta ap�s cria��o do �ndice
SELECT nome_pessoa, data_nascimento, CRM.fn_idade(data_nascimento) AS idade
FROM CRM.Pessoa 
WHERE data_nascimento >= '2020/01/01'

SELECT nome_pessoa, data_nascimento, CRM.fn_idade(data_nascimento) AS idade
FROM CRM.Pessoa 
WHERE data_nascimento >= '2021/05/01'

-- Estat�sticas
SELECT * FROM sys.objects WHERE name LIKE 'Pessoa%';
SELECT * FROM sys.stats WHERE object_id=1493580359;
SELECT * FROM sys.dm_db_stats_properties(1493580359,1);
SELECT * FROM sys.dm_db_stats_properties(1493580359,4);

DBCC SHOW_STATISTICS ('CRM.Pessoa', PK__Pessoa__C221530709258391) WITH HISTOGRAM;
DBCC SHOW_STATISTICS ('CRM.Pessoa', data_nascimento) WITH HISTOGRAM;
 
SELECT o.NAME, sc.NAME, i.NAME, sp.last_updated, sp.rows, sp.rows_sampled, 
'UPDATE STATISTICS [' + sc.NAME + '].[' + o.NAME + '] WITH  FULLSCAN' AS [Comandos]
FROM sys.objects AS o 
INNER JOIN sys.schemas sc ON (o.schema_id = sc.schema_id)
INNER JOIN sys.indexes AS i ON (o.object_id = i.object_id)
INNER JOIN sys.stats AS s ON (i.object_id = s.object_id)
CROSS apply sys.dm_db_stats_properties(s.object_id, s.stats_id) AS sp
WHERE o.type = 'U' 
AND i.is_unique = 1 
AND s.stats_id = 1 
-- AND sp.rows <> sp.rows_sampled 

-- Executa UPDATE STATISTICS na tabela CRM.Pessoa
UPDATE STATISTICS [CRM].[Pessoa] WITH FULLSCAN

-- Verificar plano de execu��o da consulta ap�s cria��o do �ndice
SELECT nome_pessoa, data_nascimento, CRM.fn_idade(data_nascimento) AS idade
FROM CRM.Pessoa 
WHERE data_nascimento >= '2021/05/01'

-- Uso de �ndices
EXEC sp_helpindex 'CRM.Pessoa'

SELECT OBJECT_NAME(IX.OBJECT_ID) Table_Name, IX.name AS Index_Name, IX.type_desc Index_Type,
SUM(PS.[used_page_count]) * 8 IndexSizeKB, 
IXUS.user_seeks AS NumOfSeeks, IXUS.user_scans AS NumOfScans,
IXUS.user_lookups AS NumOfLookups, IXUS.user_updates AS NumOfUpdates
FROM sys.indexes IX
INNER JOIN sys.dm_db_index_usage_stats IXUS ON IXUS.index_id = IX.index_id AND IXUS.OBJECT_ID = IX.OBJECT_ID
INNER JOIN sys.dm_db_partition_stats PS on PS.object_id=IX.object_id
WHERE OBJECTPROPERTY(IX.OBJECT_ID,'IsUserTable') = 1
AND OBJECT_NAME(IX.OBJECT_ID)='Pessoa'
GROUP BY OBJECT_NAME(IX.OBJECT_ID), IX.name, IX.type_desc, IXUS.user_seeks, 
IXUS.user_scans, IXUS.user_lookups, IXUS.user_updates

-- Fragmenta��o de �ndices
SELECT object_name(dm.object_id), i.name, dm.index_type_desc,
avg_fragmentation_in_percent
FROM sys.dm_db_index_physical_stats(db_id(), null, null, null, 'sampled') dm
JOIN sys.indexes i ON dm.object_id=i.object_id AND dm.index_id=i.index_id
ORDER BY avg_fragmentation_in_percent DESC

-- Rebuild do �ndice
-- Offline
ALTER INDEX ind_Pessoa_data_nascimento ON CRM.Pessoa REBUILD
-- Online
ALTER INDEX ind_Pessoa_data_nascimento ON CRM.Pessoa REBUILD WITH(ONLINE=ON)

-- Reorganize do �ndice
ALTER INDEX ind_Pessoa_data_nascimento ON CRM.Pessoa REORGANIZE


-- Verifica fragmenta��o ap�s rebuild/reorganize
SELECT object_name(dm.object_id), i.name, dm.index_type_desc,
avg_fragmentation_in_percent
FROM sys.dm_db_index_physical_stats(db_id(), null, null, null, 'sampled') dm
JOIN sys.indexes i ON dm.object_id=i.object_id AND dm.index_id=i.index_id
ORDER BY avg_fragmentation_in_percent DESC
